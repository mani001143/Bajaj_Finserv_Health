import { useState } from 'react';
import Head from 'next/head';

export default function Home() {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState(null);
  const [error, setError] = useState('');
  const [selectedOptions, setSelectedOptions] = useState([]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setResponse(null);

    try {
      const parsedInput = JSON.parse(input);
      const res = await fetch('https://your-backend-url.vercel.app/bfhl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsedInput),
      });
      const data = await res.json();
      if (data.is_success) {
        setResponse(data);
      } else {
        setError('API request failed');
      }
    } catch (err) {
      setError('Invalid JSON input');
    }
  };

  const handleOptionChange = (option) => {
    setSelectedOptions(prev => 
      prev.includes(option) 
        ? prev.filter(item => item !== option)
        : [...prev, option]
    );
  };

  return (
    <div className="min-h-screen bg-gray-100 py-6 flex flex-col justify-center sm:py-12">
      <Head>
        <title>ABCD123</title>
      </Head>
      <div className="relative py-3 sm:max-w-xl sm:mx-auto">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-light-blue-500 shadow-lg transform -skew-y-6 sm:skew-y-0 sm:-rotate-6 sm:rounded-3xl"></div>
        <div className="relative px-4 py-10 bg-white shadow-lg sm:rounded-3xl sm:p-20">
          <div className="max-w-md mx-auto">
            <div>
              <h1 className="text-2xl font-semibold">BFHL API Tester</h1>
            </div>
            <div className="divide-y divide-gray-200">
              <form onSubmit={handleSubmit} className="py-8 text-base leading-6 space-y-4 text-gray-700 sm:text-lg sm:leading-7">
                <div className="relative">
                  <textarea
                    id="input"
                    name="input"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    className="peer h-32 w-full border-2 border-gray-300 text-gray-900 focus:outline-none focus:border-rose-600 rounded-md"
                    placeholder="Enter JSON here"
                  ></textarea>
                </div>
                <button type="submit" className="bg-blue-500 text-white rounded-md px-4 py-2">Submit</button>
              </form>
              {error && <p className="text-red-500">{error}</p>}
              {response && (
                <div className="py-8">
                  <h2 className="text-xl font-semibold mb-4">Response:</h2>
                  <div className="space-y-2">
                    {['Alphabets', 'Numbers', 'Highest lowercase alphabet'].map((option) => (
                      <label key={option} className="inline-flex items-center mr-4">
                        <input
                          type="checkbox"
                          checked={selectedOptions.includes(option)}
                          onChange={() => handleOptionChange(option)}
                          className="form-checkbox h-5 w-5 text-blue-600"
                        />
                        <span className="ml-2">{option}</span>
                      </label>
                    ))}
                  </div>
                  <div className="mt-4">
                    {selectedOptions.includes('Alphabets') && (
                      <p>Alphabets: {response.alphabets.join(', ')}</p>
                    )}
                    {selectedOptions.includes('Numbers') && (
                      <p>Numbers: {response.numbers.join(', ')}</p>
                    )}
                    {selectedOptions.includes('Highest lowercase alphabet') && (
                      <p>Highest lowercase alphabet: {response.highest_lowercase_alphabet.join(', ')}</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
