import express from 'express';
import cors from 'cors';
import { Buffer } from 'buffer';

const app = express();

app.use(cors());
app.use(express.json({ limit: '10mb' }));

const USER_ID = "john_doe_17091999";
const EMAIL = "john@xyz.com";
const ROLL_NUMBER = "ABCD123";

app.post('/bfhl', (req, res) => {
  try {
    const { data, file_b64 } = req.body;

    if (!Array.isArray(data)) {
      throw new Error('Invalid input: data must be an array');
    }

    const numbers = data.filter(item => !isNaN(item));
    const alphabets = data.filter(item => isNaN(item));
    const highestLowercaseAlphabet = alphabets
      .filter(char => char.length === 1 && char === char.toLowerCase())
      .sort((a, b) => b.localeCompare(a))[0] || [];

    let fileValid = false;
    let fileMimeType = '';
    let fileSizeKb = 0;

    if (file_b64) {
      const buffer = Buffer.from(file_b64, 'base64');
      fileValid = true;
      fileMimeType = buffer[0] === 0xFF && buffer[1] === 0xD8 && buffer[2] === 0xFF ? 'image/jpeg' :
                     buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4E && buffer[3] === 0x47 ? 'image/png' :
                     buffer[0] === 0x25 && buffer[1] === 0x50 && buffer[2] === 0x44 && buffer[3] === 0x46 ? 'application/pdf' :
                     'application/octet-stream';
      fileSizeKb = Math.round(buffer.length / 1024);
    }

    res.json({
      is_success: true,
      user_id: USER_ID,
      email: EMAIL,
      roll_number: ROLL_NUMBER,
      numbers,
      alphabets,
      highest_lowercase_alphabet: highestLowercaseAlphabet ? [highestLowercaseAlphabet] : [],
      file_valid: fileValid,
      file_mime_type: fileMimeType,
      file_size_kb: fileSizeKb.toString()
    });
  } catch (error) {
    res.status(400).json({ is_success: false, error: error.message });
  }
});

app.get('/bfhl', (req, res) => {
  res.json({ operation_code: 1 });
});

export default app;
